import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-records',
  templateUrl: './health-records.component.html',
  styleUrls: ['./health-records.component.css']
})
export class HealthRecordsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
