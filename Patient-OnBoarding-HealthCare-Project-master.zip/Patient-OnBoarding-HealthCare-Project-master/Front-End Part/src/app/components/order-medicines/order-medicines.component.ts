import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-order-medicines',
  templateUrl: './order-medicines.component.html',
  styleUrls: ['./order-medicines.component.css']
})
export class OrderMedicinesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
