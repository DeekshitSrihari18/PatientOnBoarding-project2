export class BookAppointment {
    appointmentId?:number;    
    patientName?:string;    
    reasonToVisit?:string;
    date?:string;
    time?:string;
    consultationFee?:number;






 

	


	
}
