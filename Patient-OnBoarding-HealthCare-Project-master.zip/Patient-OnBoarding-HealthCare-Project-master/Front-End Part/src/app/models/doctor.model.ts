export class Doctor {

    doctorId?: number;

    doctorName?: string;

    doctorSpecialisation?: string;

    doctorPassword?: string;

}
