import { BookAppointment } from './book-appointment.model';

describe('BookAppointment', () => {
  it('should create an instance', () => {
    expect(new BookAppointment()).toBeTruthy();
  });
});
