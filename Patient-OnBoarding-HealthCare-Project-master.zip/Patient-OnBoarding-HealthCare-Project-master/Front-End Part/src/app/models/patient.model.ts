export class Patient {

    
    patientId!: number;



    patientName!: string;
    patientContact!: string;
    patientAddress!:string;	
    patientGender!: string;	
	patientAge!: number;	
	patientGaurdian!: string;	
	gaurdianContact!: string;	


    
    patientPassword!: string;

}
